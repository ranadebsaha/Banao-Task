<form method="post" action="{{url('/api/todo/add')}}">
                    <input name="user_id" type="hidden" value="{{Session::get('user_id')}}">
                    <div class="mb-3">
                        <label for="" class="form-label">Enter Task</label>
                        <input type="text" class="form-control" name="task" id="" aria-describedby="helpId"
                            placeholder="" />
                    </div>
                    <div class="mb-3">
                        <input type="submit" value="Add" class="btn btn-primary" name="submit" id="" aria-describedby="helpId"
                            placeholder="" />
                    </div>

                </form>

                $('.alert-success').html(response.message).addClass('alert').show();
                    location.reload();

                    <div class="modal fade" id="statusModal" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Change Status</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <form method="post" id="addstatus">
                                                <div class="modal-body">
                                                    <p>
                                                    <div class="mb-3">
                                                        <input type="text" class="form-control" name="task" id="task"
                                                            aria-describedby="helpId" value="{{$t->task}}" disabled />
                                                    </div>
                                                    </p>
                                                </div>
                                                <div class="mb-3">
                                                    <select class="form-select form-select-lg" name="status" id="">
                                                        <option selected value="pending">Pending</option>
                                                        <option value="done">Done</option>
                                                    </select>
                                                </div>
                                                <div class="alert-danger"></div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" class="btn btn-primary">Save</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>


                                